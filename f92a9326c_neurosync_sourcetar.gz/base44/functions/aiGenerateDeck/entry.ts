import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import {
  DECK_JSON_SCHEMA,
  buildDeckPrompt,
  sanitizeGeneratedDeck,
  unwrapLlmResult,
} from '../../shared/aiContent.ts';

// Creates one bilingual flashcard deck (max 20 cards) from a short topic
// description or from a document the user uploaded to private storage.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const topic = typeof body.prompt === 'string' ? body.prompt.trim().slice(0, 800) : '';
    const fileUri = typeof body.file_uri === 'string' ? body.file_uri.trim() : '';
    const fileName = typeof body.file_name === 'string' ? body.file_name.trim().slice(0, 150) : '';

    if (!topic && !fileUri) {
      return Response.json({ error: 'Indica un tema o sube un documento.' }, { status: 400 });
    }

    let fileUrls;
    if (fileUri) {
      const signed = await base44.asServiceRole.integrations.Core.CreateFileSignedUrl({
        file_uri: fileUri,
        expires_in: 900,
      });
      const signedUrl = unwrapLlmResult(signed)?.signed_url;
      if (!signedUrl) {
        return Response.json({ error: 'No se pudo abrir el documento.' }, { status: 400 });
      }
      fileUrls = [signedUrl];
    }

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: buildDeckPrompt({ topic, fileName }),
      response_json_schema: DECK_JSON_SCHEMA,
      ...(fileUrls ? { file_urls: fileUrls } : {}),
    });

    const deck = sanitizeGeneratedDeck(unwrapLlmResult(result));
    if (!deck.cards.length) {
      return Response.json({ error: 'No se encontraron preguntas en el contenido.' }, { status: 422 });
    }

    return Response.json(deck);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}