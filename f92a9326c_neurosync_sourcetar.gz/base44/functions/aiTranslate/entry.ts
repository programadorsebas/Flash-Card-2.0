import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import {
  MAX_TRANSLATION_TEXTS,
  TRANSLATION_JSON_SCHEMA,
  buildTranslationPrompt,
  unwrapLlmResult,
} from '../../shared/aiContent.ts';

// Translates up to 6 short texts (a deck name, a question and an answer)
// between Spanish and English so a card only has to be written once.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const target = body.target === 'en' ? 'en' : body.target === 'es' ? 'es' : '';
    const texts = Array.isArray(body.texts)
      ? body.texts
          .filter((text) => typeof text === 'string')
          .slice(0, MAX_TRANSLATION_TEXTS)
          .map((text) => text.trim().slice(0, 600))
      : [];

    if (!target || !texts.length || !texts.some((text) => text)) {
      return Response.json({ error: 'Faltan los textos por traducir.' }, { status: 400 });
    }

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: buildTranslationPrompt(texts, target),
      response_json_schema: TRANSLATION_JSON_SCHEMA,
    });

    const data = unwrapLlmResult(result);
    const list = Array.isArray(data?.translations) ? data.translations : [];
    const translations = texts.map((text, index) => {
      const value = list[index];
      return typeof value === 'string' && value.trim() ? value.trim().slice(0, 600) : text;
    });

    return Response.json({ translations });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}