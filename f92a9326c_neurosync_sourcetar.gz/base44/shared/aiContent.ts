// Shared AI helpers for the Memorable flashcard app.
// Used by the aiGenerateDeck and aiTranslate backend functions.

export const MAX_DECK_CARDS = 20;
export const MAX_TRANSLATION_TEXTS = 6;

export const DECK_JSON_SCHEMA = {
  type: "object",
  properties: {
    title_es: { type: "string" },
    title_en: { type: "string" },
    description_es: { type: "string" },
    description_en: { type: "string" },
    emoji: { type: "string" },
    cards: {
      type: "array",
      items: {
        type: "object",
        properties: {
          front_es: { type: "string" },
          back_es: { type: "string" },
          front_en: { type: "string" },
          back_en: { type: "string" },
        },
        required: ["front_es", "back_es", "front_en", "back_en"],
      },
    },
  },
  required: ["title_es", "title_en", "description_es", "description_en", "emoji", "cards"],
};

export const TRANSLATION_JSON_SCHEMA = {
  type: "object",
  properties: {
    translations: { type: "array", items: { type: "string" } },
  },
  required: ["translations"],
};

export function buildDeckPrompt({ topic, fileName }) {
  const lines = [
    "Eres un asistente que crea mazos de tarjetas de memoria para personas mayores que ejercitan la mente.",
    "Reglas:",
    "- Escribe siempre en español (Venezuela) y en inglés, con frases cortas y palabras sencillas.",
    `- Crea entre 8 y ${MAX_DECK_CARDS} tarjetas y nunca más de ${MAX_DECK_CARDS}.`,
    "- Cada tarjeta lleva una pregunta clara y una respuesta breve, fácil de recordar.",
    "- La pregunta y la respuesta deben decir lo mismo en los dos idiomas.",
    "- Incluye un título corto en cada idioma, una descripción de una sola frase en cada idioma y un emoji que represente el tema.",
  ];
  if (topic) lines.push(`- Tema del mazo: ${topic}`);
  if (fileName) {
    lines.push(`- Usa únicamente el contenido del documento adjunto "${fileName}" para armar las tarjetas.`);
  }
  lines.push("Responde solo con el JSON solicitado.");
  return lines.join("\n");
}

export function buildTranslationPrompt(texts, target) {
  const language = target === "en" ? "inglés (Australia), natural y sencillo" : "español de Venezuela, natural y sencillo";
  return [
    `Traduce cada texto al ${language}.`,
    "Mantén el mismo orden y la misma cantidad de textos, sin agregar ni quitar elementos.",
    "Traduce con naturalidad, como lo diría una persona mayor en una conversación.",
    "Responde solo con el JSON solicitado.",
    "Textos:",
    ...texts.map((text, index) => `${index + 1}. ${text}`),
  ].join("\n");
}

function cleanString(value, maxLength = 600) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

export function sanitizeGeneratedDeck(raw) {
  const source = raw && typeof raw === "object" ? raw : {};
  const rawCards = Array.isArray(source.cards) ? source.cards : [];

  const cards = rawCards
    .slice(0, MAX_DECK_CARDS)
    .map((card) => {
      const frontEs = cleanString(card?.front_es, 300);
      const backEs = cleanString(card?.back_es, 500);
      return {
        front_es: frontEs,
        back_es: backEs,
        front_en: cleanString(card?.front_en, 300) || frontEs,
        back_en: cleanString(card?.back_en, 500) || backEs,
      };
    })
    .filter((card) => card.front_es && card.back_es);

  const titleEs = cleanString(source.title_es, 80) || cleanString(source.title_en, 80) || "Mazo nuevo";
  const titleEn = cleanString(source.title_en, 80) || titleEs;

  return {
    title_es: titleEs,
    title_en: titleEn,
    description_es: cleanString(source.description_es, 200) || "Mazo creado con inteligencia artificial.",
    description_en: cleanString(source.description_en, 200) || "Deck created with artificial intelligence.",
    emoji: cleanString(source.emoji, 8) || "🌟",
    cards,
  };
}

export function unwrapLlmResult(result) {
  if (result && typeof result === "object" && !Array.isArray(result) && "data" in result) {
    return result.data;
  }
  return result;
}