import React from 'react';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';
import { cn } from '@/lib/utils';

export default function Flashcard({ front, back, flipped, onFlip, onSpeak }) {
  const { t } = useSettings();

  const flip = () => {
    playSound('flip');
    onFlip();
  };

  return (
    <div className="flex flex-col items-center justify-center py-4">
      <div
        role="button"
        tabIndex={0}
        aria-label={t('lblFlipInstruction')}
        onClick={flip}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            flip();
          }
        }}
        className="w-full max-w-xl h-80 perspective-1000 cursor-pointer focus:outline-none focus:ring-4 focus:ring-indigo-300 rounded-3xl"
      >
        <div
          className={cn(
            'relative w-full h-full transform-style-3d transition-transform duration-500',
            flipped && 'rotate-y-180'
          )}
        >
          <div className="absolute w-full h-full bg-white border-4 border-indigo-600 rounded-3xl shadow-xl p-6 flex flex-col justify-between items-center backface-hidden text-center">
            <span className="text-xs uppercase font-black tracking-widest text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
              {t('lblPreguntaTag')}
            </span>
            <p className="text-xl md:text-2xl font-black text-slate-800 my-auto px-2">{front}</p>
            <div className="flex justify-between items-center w-full gap-2 border-t border-slate-100 pt-3">
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  onSpeak(front);
                }}
                className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 px-4 py-2.5 rounded-2xl flex items-center gap-1.5 font-bold shadow-sm"
              >
                📢 <span>{t('btnSpeakFront')}</span>
              </button>
              <span className="text-sm font-bold text-slate-500 animate-bounce">{t('lblSeeAnswer')}</span>
            </div>
          </div>

          <div className="absolute w-full h-full bg-indigo-50 border-4 border-indigo-700 rounded-3xl shadow-xl p-6 flex flex-col justify-between items-center backface-hidden text-center rotate-y-180">
            <span className="text-xs uppercase font-black tracking-widest text-indigo-700 bg-indigo-100 px-3 py-1 rounded-full border border-indigo-200">
              {t('lblRespuestaTag')}
            </span>
            <p className="text-xl md:text-2xl font-black text-indigo-950 my-auto px-2">{back}</p>
            <div className="flex justify-between items-center w-full gap-2 border-t border-indigo-100 pt-3">
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  onSpeak(back);
                }}
                className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 px-4 py-2.5 rounded-2xl flex items-center gap-1.5 font-bold shadow-sm"
              >
                📢 <span>{t('btnSpeakBack')}</span>
              </button>
              <span className="text-sm font-bold text-slate-500">{t('lblBackTag')}</span>
            </div>
          </div>
        </div>
      </div>

      <p className="text-center text-slate-500 mt-4 text-sm font-bold">{t('lblFlipInstruction')}</p>
    </div>
  );
}