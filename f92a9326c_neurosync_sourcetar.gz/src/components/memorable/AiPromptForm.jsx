import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { generateAndSaveDeck } from '@/lib/memorable/decks';
import { playSound } from '@/lib/memorable/audio';

export default function AiPromptForm() {
  const { t } = useSettings();
  const navigate = useNavigate();
  const [topic, setTopic] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const handleCreate = async () => {
    if (!topic.trim()) {
      setError(t('errNeedInput'));
      return;
    }
    setBusy(true);
    setError('');
    try {
      const deck = await generateAndSaveDeck({ prompt: topic.trim() });
      playSound('success');
      navigate(`/mazo/${deck.id}`);
    } catch {
      setError(t('errEmptyDeck'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="bg-white p-6 rounded-3xl border-2 border-indigo-100 shadow-md space-y-4">
      <div>
        <h2 className="font-black text-slate-800 flex items-center gap-2">
          <span>🤖</span> <span>{t('aiPromptTitle')}</span>
        </h2>
        <p className="text-sm text-slate-500">{t('aiPromptDesc')}</p>
      </div>

      <div>
        <label htmlFor="ai-topic" className="block font-bold text-slate-700 mb-1">
          {t('lblAiTopic')}
        </label>
        <textarea
          id="ai-topic"
          rows={3}
          value={topic}
          onChange={(event) => setTopic(event.target.value)}
          placeholder={t('phAiTopic')}
          className="w-full p-3 border-2 border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-100"
        />
      </div>

      <p className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-xl p-3">
        ✨ {t('aiLimitNote')} {t('aiPrivateNote')}
      </p>

      {error && <p className="text-sm font-bold text-red-700 bg-red-50 border border-red-200 rounded-xl p-3">{error}</p>}

      <button
        type="button"
        onClick={handleCreate}
        disabled={busy}
        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold py-4 px-6 rounded-2xl shadow-md text-lg flex items-center justify-center gap-2 disabled:opacity-60"
      >
        {busy ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" /> {t('aiGenerating')}
          </>
        ) : (
          t('btnAiCreateDeck')
        )}
      </button>
    </section>
  );
}