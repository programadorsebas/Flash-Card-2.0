import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { generateAndSaveDeck } from '@/lib/memorable/decks';
import { playSound } from '@/lib/memorable/audio';

const ACCEPTED = ['.pdf', '.docx', '.doc', '.txt', '.png', '.jpg', '.jpeg', '.webp'];
const MAX_BYTES = 10 * 1024 * 1024;

export default function AiFileForm() {
  const { t } = useSettings();
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const pickFile = (selected) => {
    setError('');
    if (!selected) {
      setFile(null);
      return;
    }
    const extension = `.${selected.name.split('.').pop().toLowerCase()}`;
    if (!ACCEPTED.includes(extension)) {
      setError(t('errFileType'));
      return;
    }
    if (selected.size > MAX_BYTES) {
      setError(t('errFileTooLarge'));
      return;
    }
    setFile(selected);
  };

  const handleCreate = async () => {
    if (!file) {
      setError(t('errNeedInput'));
      return;
    }
    setBusy(true);
    setError('');
    try {
      const upload = await base44.integrations.Core.UploadPrivateFile({ file });
      const deck = await generateAndSaveDeck({ file_uri: upload.file_uri, file_name: file.name });
      playSound('success');
      navigate(`/mazo/${deck.id}`);
    } catch {
      setError(t('errEmptyDeck'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="bg-white p-6 rounded-3xl border-2 border-emerald-100 shadow-md space-y-4">
      <div>
        <h2 className="font-black text-slate-800 flex items-center gap-2">
          <span>📄</span> <span>{t('aiUploadTitle')}</span>
        </h2>
        <p className="text-sm text-slate-500">{t('aiUploadDesc')}</p>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED.join(',')}
        className="hidden"
        onChange={(event) => pickFile(event.target.files?.[0])}
      />

      <button
        type="button"
        onClick={() => {
          playSound('click');
          inputRef.current?.click();
        }}
        className="w-full border-4 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50 rounded-2xl p-6 text-center font-bold text-emerald-900"
      >
        <span className="block text-3xl mb-1">📎</span>
        {file ? file.name : t('btnChooseFile')}
      </button>

      <p className="text-xs text-emerald-800 font-semibold">{t('aiUploadNote')}</p>
      <p className="text-xs font-bold text-indigo-700">{t('aiLimitNote')}</p>

      {error && <p className="text-sm font-bold text-red-700 bg-red-50 border border-red-200 rounded-xl p-3">{error}</p>}

      <button
        type="button"
        onClick={handleCreate}
        disabled={busy || !file}
        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-4 px-6 rounded-2xl shadow-md text-lg flex items-center justify-center gap-2 disabled:opacity-60"
      >
        {busy ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" /> {t('aiGenerating')}
          </>
        ) : (
          t('btnAiFromFile')
        )}
      </button>
    </section>
  );
}