import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';

export default function CongratsPanel({ reviewed }) {
  const { t } = useSettings();

  useEffect(() => {
    playSound('success');
  }, []);

  return (
    <div className="bg-white border-4 border-indigo-500 p-8 rounded-3xl shadow-2xl space-y-6 text-center">
      <div className="text-7xl animate-bounce">🏆🌟</div>
      <h2 className="font-black text-indigo-800">{t('congratsTitle')}</h2>
      <p className="text-lg text-slate-600 max-w-lg mx-auto">{t('congratsSubtitle')}</p>

      <div className="bg-amber-50 border-4 border-amber-300 p-6 rounded-2xl max-w-sm mx-auto space-y-2 shadow-inner">
        <span className="text-4xl">🎖️</span>
        <h3 className="font-black text-amber-900">{t('badgeEarned')}</h3>
        <p className="text-xs text-amber-700 font-bold">{t('badgeDesc')}</p>
      </div>

      <div className="bg-indigo-50 border-2 border-indigo-200 rounded-2xl p-6 max-w-md mx-auto space-y-2">
        <h3 className="font-bold text-indigo-950">{t('congratsSummaryTitle')}</h3>
        <p className="font-semibold text-slate-700">
          {t('congratsReviewedText')}: <span className="font-black text-indigo-800">{reviewed}</span>
        </p>
        <p className="text-sm text-slate-500">{t('congratsTip')}</p>
      </div>

      <div className="flex justify-center pt-2">
        <Link
          to="/"
          onClick={() => playSound('click')}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-black px-8 py-4 rounded-2xl shadow-md text-lg"
        >
          {t('btnGoHomeCongrats')}
        </Link>
      </div>
    </div>
  );
}