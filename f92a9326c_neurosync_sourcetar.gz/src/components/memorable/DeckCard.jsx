import React from 'react';
import { Link } from 'react-router-dom';
import { deckDescription, deckTitle } from '@/lib/memorable/decks';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';

export default function DeckCard({ deck, cardCount }) {
  const { t, language } = useSettings();

  return (
    <div className="bg-white rounded-3xl border-2 border-indigo-50 shadow-md p-6 hover:shadow-xl hover:border-indigo-200 transition-all flex flex-col justify-between gap-4">
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <span className="text-4xl p-3 bg-indigo-50 rounded-2xl" role="img" aria-label={deckTitle(deck, language)}>
            {deck.emoji || '🌟'}
          </span>
          <div>
            <h3 className="font-extrabold text-slate-900">{deckTitle(deck, language)}</h3>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs bg-indigo-100 text-indigo-800 font-extrabold px-3 py-1 rounded-full border border-indigo-200">
                {cardCount} {t('lblCards')}
              </span>
              {deck.is_example && (
                <span className="text-xs bg-emerald-100 text-emerald-800 font-extrabold px-3 py-1 rounded-full border border-emerald-200">
                  {t('lblSample')}
                </span>
              )}
            </div>
          </div>
        </div>
        <p className="text-slate-600 text-sm leading-relaxed">{deckDescription(deck, language)}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
        <Link
          to={`/estudiar/${deck.id}`}
          onClick={() => playSound('click')}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold py-3.5 px-4 rounded-2xl flex items-center justify-center gap-1 shadow-md"
        >
          ▶️ {t('btnStudy')}
        </Link>
        <Link
          to={`/mazo/${deck.id}`}
          onClick={() => playSound('click')}
          className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-3.5 px-4 rounded-2xl flex items-center justify-center gap-1"
        >
          ✏️ {t('btnEdit')}
        </Link>
      </div>
    </div>
  );
}