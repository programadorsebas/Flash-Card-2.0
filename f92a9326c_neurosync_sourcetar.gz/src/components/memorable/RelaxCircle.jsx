import React, { useEffect, useState } from 'react';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { speakText, stopSpeech } from '@/lib/memorable/audio';

export default function RelaxCircle() {
  const { t, audioEnabled } = useSettings();
  const [inhale, setInhale] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => setInhale((value) => !value), 3000);
    return () => {
      clearInterval(timer);
      stopSpeech();
    };
  }, []);

  useEffect(() => {
    if (audioEnabled) speakText(inhale ? t('breatheIn') : t('breatheOut'));
  }, [inhale, audioEnabled]);

  return (
    <div className="flex items-center justify-center my-10">
      <div className="w-48 h-48 rounded-full breathing-circle flex items-center justify-center text-white font-extrabold text-2xl shadow-inner shadow-indigo-600">
        <span className="drop-shadow">{inhale ? t('breatheIn') : t('breatheOut')}</span>
      </div>
    </div>
  );
}