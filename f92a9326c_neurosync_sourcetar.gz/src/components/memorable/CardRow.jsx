import React from 'react';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';
import { cn } from '@/lib/utils';

const BOX_STYLES = {
  1: 'bg-red-100 text-red-800',
  2: 'bg-amber-100 text-amber-800',
  3: 'bg-emerald-100 text-emerald-800',
};

export default function CardRow({ card, box, canDelete, onDelete }) {
  const { t } = useSettings();

  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
      <div className="space-y-1">
        <p className="text-xs text-slate-400 font-bold">
          {t('lblCard')}
          <span className={cn('ml-2 text-xs font-black uppercase px-2 py-0.5 rounded-full', BOX_STYLES[box] || BOX_STYLES[1])}>
            {t('lblBox')} {box}
          </span>
        </p>
        <div className="text-sm">
          <p className="font-bold text-slate-800">
            <span className="text-indigo-700">ES:</span> {card.front_es}{' '}
            <span className="text-slate-500 font-normal">→ {card.back_es}</span>
          </p>
          <p className="font-bold text-slate-700 mt-1">
            <span className="text-purple-600">EN:</span> {card.front_en}{' '}
            <span className="text-slate-500 font-normal">→ {card.back_en}</span>
          </p>
        </div>
      </div>

      {canDelete && (
        <button
          type="button"
          onClick={() => {
            playSound('click');
            onDelete(card);
          }}
          className="bg-red-50 hover:bg-red-100 text-red-700 px-3 py-1.5 rounded-lg text-sm font-bold border border-red-200 shrink-0"
        >
          🗑️ {t('btnDeleteCard')}
        </button>
      )}
    </div>
  );
}