import React, { useState } from 'react';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';

const BOXES = [
  { key: 'box1', countKey: 'box1', emoji: '🔴', sub: 'box1Sub', label: 'box1', frame: 'bg-red-50 border-red-200', title: 'text-red-900', sub2: 'text-red-700', number: 'text-red-800' },
  { key: 'box2', countKey: 'box2', emoji: '🟡', sub: 'box2Sub', label: 'box2', frame: 'bg-amber-50 border-amber-200', title: 'text-amber-900', sub2: 'text-amber-700', number: 'text-amber-800' },
  { key: 'box3', countKey: 'box3', emoji: '🟢', sub: 'box3Sub', label: 'box3', frame: 'bg-emerald-50 border-emerald-200', title: 'text-emerald-900', sub2: 'text-emerald-700', number: 'text-emerald-800' },
];

export default function LeitnerBoxes({ summary }) {
  const { t } = useSettings();
  const [showHelp, setShowHelp] = useState(false);

  return (
    <section className="bg-white rounded-3xl p-6 border-2 border-indigo-100 shadow-sm space-y-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-slate-100 pb-3">
        <div>
          <h3 className="font-extrabold text-slate-900 flex items-center gap-2">
            <span>🗂️</span> <span>{t('leitnerTitle')}</span>
          </h3>
          <p className="text-sm text-slate-500">{t('leitnerSubtitle')}</p>
        </div>
        <button
          type="button"
          onClick={() => {
            playSound('click');
            setShowHelp(true);
          }}
          className="text-indigo-600 hover:text-indigo-800 font-extrabold text-sm underline flex items-center gap-1 rounded px-1"
        >
          <span>💡</span> <span>{t('btnHowItWorks')}</span>
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3 md:gap-6 text-center">
        {BOXES.map((box) => (
          <div key={box.key} className={`${box.frame} border-4 p-4 rounded-2xl flex flex-col justify-between`}>
            <div>
              <span className="text-3xl block">{box.emoji}</span>
              <span className={`font-black block text-base md:text-lg ${box.title}`}>{t(box.label)}</span>
              <span className={`text-xs font-bold uppercase tracking-wider ${box.sub2}`}>{t(box.sub)}</span>
            </div>
            <div className="mt-3">
              <span className={`text-3xl font-black ${box.number}`}>{summary?.[box.countKey] ?? 0}</span>
              <span className="block text-xs text-slate-500 font-bold">{t('boxCard')}</span>
            </div>
          </div>
        ))}
      </div>

      {showHelp && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full border-4 border-indigo-600 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h3 className="font-black text-indigo-800">{t('leitnerTitle')}</h3>
              <button type="button" onClick={() => setShowHelp(false)} className="text-slate-400 hover:text-slate-600 text-2xl font-bold">
                ×
              </button>
            </div>
            <div className="text-slate-700 space-y-3 text-left">
              <p className="text-base">{t('leitnerHelpIntro')}</p>
              {[
                { emoji: '🔴', title: 'leitnerHelpBox1Title', text: 'leitnerHelpBox1Text', tone: 'text-red-800' },
                { emoji: '🟡', title: 'leitnerHelpBox2Title', text: 'leitnerHelpBox2Text', tone: 'text-amber-800' },
                { emoji: '🟢', title: 'leitnerHelpBox3Title', text: 'leitnerHelpBox3Text', tone: 'text-emerald-800' },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-2">
                  <span className="text-xl">{item.emoji}</span>
                  <div>
                    <strong className={`block ${item.tone}`}>{t(item.title)}</strong>
                    <span className="text-sm text-slate-600">{t(item.text)}</span>
                  </div>
                </div>
              ))}
              <p className="text-sm border-t border-slate-100 pt-2 text-slate-500 font-semibold italic">{t('leitnerHelpNote')}</p>
            </div>
            <button
              type="button"
              onClick={() => {
                playSound('click');
                setShowHelp(false);
              }}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl"
            >
              {t('modalBtnUnderstand')}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}