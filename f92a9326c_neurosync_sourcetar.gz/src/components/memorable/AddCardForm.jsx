import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';
import { translateTexts } from '@/lib/memorable/decks';
import { toast } from '@/components/ui/use-toast';

const LANGUAGE_NAMES = { es: 'Español', en: 'English' };

export default function AddCardForm({ deckId, onAdded }) {
  const { t, language } = useSettings();
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  const [translation, setTranslation] = useState(null);
  const [sourceLang, setSourceLang] = useState(language);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const targetLang = sourceLang === 'es' ? 'en' : 'es';

  // The card is written in whichever language the app is showing, until the form has content.
  useEffect(() => {
    if (!front && !back) setSourceLang(language);
  }, [language, front, back]);

  const runTranslation = async () => {
    const values = await translateTexts([front.trim(), back.trim()], targetLang);
    const next = { front: values[0] || '', back: values[1] || '' };
    setTranslation(next);
    return next;
  };

  const handleTranslate = async () => {
    if (!front.trim() || !back.trim()) {
      setError(t('errEmptyFields'));
      return;
    }
    setBusy(true);
    setError('');
    try {
      await runTranslation();
    } catch {
      setError(t('errGeneric'));
    } finally {
      setBusy(false);
    }
  };

  const handleSave = async () => {
    if (!front.trim() || !back.trim()) {
      setError(t('errEmptyFields'));
      return;
    }
    setBusy(true);
    setError('');
    try {
      let translated = translation;
      if (!translated?.front?.trim() || !translated?.back?.trim()) {
        translated = await runTranslation();
      }

      const payload =
        sourceLang === 'es'
          ? { front_es: front.trim(), back_es: back.trim(), front_en: translated.front, back_en: translated.back }
          : { front_en: front.trim(), back_en: back.trim(), front_es: translated.front, back_es: translated.back };

      await base44.entities.Card.create({ ...payload, deck_id: deckId, is_example: false });
      playSound('success');
      setFront('');
      setBack('');
      setTranslation(null);
      toast({ title: t('cardSaved') });
      onAdded();
    } catch {
      setError(t('errGeneric'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-indigo-50 border-2 border-indigo-200 p-6 rounded-3xl shadow-sm space-y-4">
      <h3 className="font-bold text-indigo-950 flex items-center gap-1">
        <span>➕</span> <span>{t('titleAddCardForm')}</span>
      </h3>

      <p className="text-sm font-bold text-indigo-700">
        {t('lblWritingIn')} <span className="uppercase">{LANGUAGE_NAMES[sourceLang]}</span> · {t('lblAiTranslation').replace(':', '')}
      </p>

      <div className="space-y-3 bg-white p-4 rounded-2xl border border-indigo-100 shadow-sm">
        <div>
          <label htmlFor="card-front" className="block text-sm font-bold text-slate-500 mb-1">
            {t('lblQuestion')}
          </label>
          <textarea
            id="card-front"
            rows={2}
            value={front}
            onChange={(event) => setFront(event.target.value)}
            placeholder={t('phQuestion')}
            className="w-full p-3 border-2 border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-100"
          />
        </div>
        <div>
          <label htmlFor="card-back" className="block text-sm font-bold text-slate-500 mb-1">
            {t('lblAnswer')}
          </label>
          <textarea
            id="card-back"
            rows={2}
            value={back}
            onChange={(event) => setBack(event.target.value)}
            placeholder={t('phAnswer')}
            className="w-full p-3 border-2 border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-100"
          />
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <button
          type="button"
          onClick={handleTranslate}
          disabled={busy}
          className="bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold px-5 py-3 rounded-2xl shadow-md flex-1 disabled:opacity-60"
        >
          {busy ? t('translating') : t('btnAiTranslate')}
        </button>
        <button
          type="button"
          onClick={handleSave}
          disabled={busy}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-5 py-3 rounded-2xl shadow-md flex-1 disabled:opacity-60"
        >
          ✨ {t('btnAddCard')}
        </button>
      </div>

      {translation && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-white p-4 rounded-2xl border-2 border-dashed border-indigo-300">
          <p className="md:col-span-2 text-sm font-black text-indigo-700">
            🌐 {t('lblAiTranslation')} <span className="uppercase">{LANGUAGE_NAMES[targetLang]}</span>
          </p>
          <input
            value={translation.front}
            onChange={(event) => setTranslation({ ...translation, front: event.target.value })}
            className="w-full p-3 border-2 border-slate-200 rounded-xl"
          />
          <input
            value={translation.back}
            onChange={(event) => setTranslation({ ...translation, back: event.target.value })}
            className="w-full p-3 border-2 border-slate-200 rounded-xl"
          />
        </div>
      )}

      {error && <p className="text-sm font-bold text-red-700 bg-red-50 border border-red-200 rounded-xl p-3">{error}</p>}
    </div>
  );
}