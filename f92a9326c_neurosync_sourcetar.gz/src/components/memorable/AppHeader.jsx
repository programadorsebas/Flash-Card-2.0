import React from 'react';
import { Link } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { useAuth } from '@/lib/AuthContext';
import { playSound } from '@/lib/memorable/audio';
import { cn } from '@/lib/utils';
import { Image } from '@/components/ui/image';

export default function AppHeader() {
  const {
    t,
    language,
    setLanguage,
    textSize,
    setTextSize,
    audioEnabled,
    toggleAudio,
    highContrast,
    toggleContrast,
  } = useSettings();
  const { logout } = useAuth();

  return (
    <header
      className={cn(
        'backdrop-blur-md border-b-4 sticky top-0 z-50 shadow-lg',
        highContrast ? 'bg-slate-900 border-yellow-400' : 'bg-white/80 border-indigo-600'
      )}
    >
      <div className="max-w-4xl mx-auto px-4 py-3 flex flex-col gap-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <Link
            to="/"
            onClick={() => playSound('click')}
            className="flex items-center gap-3 rounded-2xl p-1 focus:outline-none focus:ring-4 focus:ring-indigo-400"
          >
            <Image
              src="https://media.base44.com/images/public/6acd84899030f2ba7035404a/07021c283_generated_image.png"
              alt={t('appName')}
              className="w-14 h-14 rounded-2xl shadow-md shrink-0"
            />
            <span className="text-left">
              <span className={cn('block text-2xl font-black tracking-tight', highContrast ? 'text-yellow-300' : 'text-slate-900')}>
                {t('appName').slice(0, 5)}
                <span className={highContrast ? '' : 'text-teal-500'}>{t('appName').slice(5)}</span>
              </span>
              <span className="text-xs text-indigo-500 font-black block -mt-1 uppercase tracking-widest">
                {t('appTagline')}
              </span>
            </span>
          </Link>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border-2 border-slate-300 shadow-inner">
              {[
                { code: 'es', flag: '🇻🇪', label: 'Español' },
                { code: 'en', flag: '🇦🇺', label: 'English' },
              ].map((option) => (
                <button
                  key={option.code}
                  type="button"
                  onClick={() => {
                    playSound('click');
                    setLanguage(option.code);
                  }}
                  className={cn(
                    'px-3 py-2 rounded-xl flex items-center gap-2 transition-all',
                    language === option.code
                      ? 'bg-indigo-600 text-white font-black shadow-md'
                      : 'bg-slate-100 text-slate-700 font-bold hover:bg-slate-200'
                  )}
                >
                  <span className="text-xl">{option.flag}</span>
                  <span className="text-sm hidden sm:inline">{option.label}</span>
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => logout()}
              title={t('btnLogout')}
              className="px-3 py-2 rounded-2xl border border-slate-300 bg-white text-slate-700 hover:bg-indigo-50 font-bold shadow-sm flex items-center gap-1.5"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm hidden sm:inline">{t('btnLogout')}</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between flex-wrap gap-3 pt-2 border-t border-slate-100">
          <div className="bg-slate-100 p-1 rounded-2xl flex items-center border border-slate-300 shadow-sm">
            <span className="text-xs font-bold text-slate-600 px-3 uppercase tracking-wider">{t('lblLetra')}</span>
            {[
              { size: 1, label: 'A' },
              { size: 2, label: 'A+' },
              { size: 3, label: 'A++' },
            ].map((option) => (
              <button
                key={option.size}
                type="button"
                onClick={() => {
                  playSound('click');
                  setTextSize(option.size);
                }}
                className={cn(
                  'px-4 py-1.5 rounded-xl border focus:ring-2 focus:ring-indigo-500',
                  textSize === option.size
                    ? 'bg-indigo-600 text-white font-black shadow-md border-indigo-600'
                    : 'bg-white text-slate-800 font-bold border-slate-200 hover:bg-slate-50'
                )}
              >
                {option.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              playSound('click');
              toggleAudio();
            }}
            className={cn(
              'px-4 py-2 rounded-2xl border font-bold shadow-sm flex items-center gap-2 focus:ring-4 focus:ring-indigo-300',
              audioEnabled
                ? 'border-slate-300 bg-white text-slate-700 hover:bg-indigo-50'
                : 'border-red-300 bg-red-50 text-red-800'
            )}
          >
            <span className="text-xl">{audioEnabled ? '🔊' : '🔇'}</span>
            <span className="text-sm">{audioEnabled ? t('audioOn') : t('audioOff')}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              playSound('click');
              toggleContrast();
            }}
            className={cn(
              'px-4 py-2 rounded-2xl border font-bold shadow-sm flex items-center gap-2 focus:ring-4 focus:ring-indigo-300',
              highContrast
                ? 'bg-yellow-400 text-slate-950 border-yellow-400'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-indigo-50'
            )}
          >
            <span className="text-xl">🌓</span>
            <span className="text-sm">{t('btnContraste')}</span>
          </button>
        </div>
      </div>
    </header>
  );
}