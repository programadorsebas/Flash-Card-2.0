import React from 'react';
import { Outlet } from 'react-router-dom';
import { SettingsProvider, useSettings } from '@/lib/memorable/SettingsContext';
import AppHeader from '@/components/memorable/AppHeader';
import { cn } from '@/lib/utils';

function Shell() {
  const { highContrast } = useSettings();

  return (
    <div
      id="appBody"
      className={cn(
        'min-h-screen transition-all duration-300',
        highContrast
          ? 'bg-slate-950 text-yellow-300'
          : 'bg-gradient-to-br from-indigo-50 via-blue-50 to-emerald-50 text-slate-800'
      )}
    >
      <AppHeader />
      <main className="max-w-4xl mx-auto px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}

export default function MemorableLayout() {
  return (
    <SettingsProvider>
      <Shell />
    </SettingsProvider>
  );
}