import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { translateTexts } from '@/lib/memorable/decks';
import { playSound } from '@/lib/memorable/audio';

const EMOJIS = ['🦘', '🐨', '⛵', '🌳', '🍪', '🗺️', '🌟'];

export default function CreateDeck() {
  const { t, language, otherLanguage } = useSettings();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [emoji, setEmoji] = useState(EMOJIS[0]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    const title = name.trim();
    if (!title) {
      setError(t('errEmptyFields'));
      return;
    }
    setBusy(true);
    setError('');
    try {
      // Only one name is typed; the AI writes the other language.
      const [translatedTitle] = await translateTexts([title], otherLanguage);

      const deck = await base44.entities.Deck.create({
        title_es: language === 'es' ? title : translatedTitle,
        title_en: language === 'en' ? title : translatedTitle,
        description_es: 'Mazo personalizado por el usuario.',
        description_en: 'User created custom deck.',
        emoji,
        is_example: false,
      });

      playSound('success');
      navigate(`/mazo/${deck.id}`);
    } catch {
      setError(t('errGeneric'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-3xl border-2 border-indigo-100 shadow-md space-y-6">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <h1 className="font-black text-slate-800 flex items-center gap-2">
          <span>🆕</span> <span>{t('titleCreateDeck')}</span>
        </h1>
        <Link to="/" className="text-slate-500 hover:text-slate-700 font-bold px-3 py-1.5 bg-slate-100 rounded-xl">
          {t('btnCancel')}
        </Link>
      </div>

      <div className="space-y-4">
        <div>
          <label htmlFor="deck-name" className="block font-bold text-slate-700 mb-1">
            {t('lblDeckName')}
          </label>
          <input
            id="deck-name"
            type="text"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder={t('phDeckName')}
            className="w-full p-3 border-2 border-slate-300 rounded-xl focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-100 font-bold"
          />
          <p className="text-xs font-bold text-indigo-700 mt-2">✨ {t('aiLimitNote').split(',')[0]}</p>
        </div>

        <div>
          <span className="block font-bold text-slate-700 mb-1">{t('lblPickEmoji')}</span>
          <div className="flex flex-wrap gap-2">
            {EMOJIS.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => {
                  playSound('click');
                  setEmoji(option);
                }}
                className={`p-3 rounded-xl text-2xl border-2 transition-all ${
                  emoji === option ? 'border-indigo-600 bg-indigo-50' : 'border-transparent bg-slate-100 hover:bg-slate-200'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-sm font-bold text-red-700 bg-red-50 border border-red-200 rounded-xl p-3">{error}</p>}

        <button
          type="button"
          onClick={handleSave}
          disabled={busy}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold py-4 px-6 rounded-2xl shadow-md text-lg flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {busy ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" /> {t('saving')}
            </>
          ) : (
            t('btnSaveDeck')
          )}
        </button>
      </div>
    </div>
  );
}