import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import confetti from 'canvas-confetti';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useSettings } from '@/lib/memorable/SettingsContext';
import {
  boxOf,
  deckTitle,
  listCards,
  myProgressByCard,
  saveCardBox,
  sideText,
} from '@/lib/memorable/decks';
import { playSound, speakText } from '@/lib/memorable/audio';
import Flashcard from '@/components/memorable/Flashcard';
import CongratsPanel from '@/components/memorable/CongratsPanel';

export default function Study() {
  const { deckId } = useParams();
  const { user } = useAuth();
  const { t, language, audioEnabled, addStars, completeSession } = useSettings();

  const [deck, setDeck] = useState(null);
  const [cards, setCards] = useState(null);
  const [progress, setProgress] = useState({});
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [reviewed, setReviewed] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      const [deckRecord, cardList] = await Promise.all([base44.entities.Deck.get(deckId), listCards(deckId)]);
      const progressMap = await myProgressByCard(deckId, user?.id);
      if (!active) return;
      setDeck(deckRecord);
      setProgress(progressMap);
      setCards([...cardList].sort((a, b) => boxOf(progressMap, a.id) - boxOf(progressMap, b.id)));
    })();
    return () => {
      active = false;
    };
  }, [deckId, user?.id]);

  const current = cards?.[index];

  useEffect(() => {
    if (!audioEnabled || !current) return;
    const timer = setTimeout(() => speakText(sideText(current, language, 'front')), 400);
    return () => clearTimeout(timer);
  }, [current?.id, audioEnabled, language]);

  const handleEvaluate = async (remembered) => {
    const card = cards[index];
    const nextBox = remembered ? Math.min(3, boxOf(progress, card.id) + 1) : 1;
    const saved = await saveCardBox({ cardId: card.id, deckId, box: nextBox, progressId: progress[card.id]?.id });

    setProgress((map) => ({ ...map, [card.id]: saved }));
    if (remembered) addStars(2);
    else playSound('fail');
    setReviewed((value) => value + 1);

    if (index + 1 < cards.length) {
      setFlipped(false);
      setIndex(index + 1);
    } else {
      setFinished(true);
      completeSession();
      confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 } });
    }
  };

  if (cards === null) {
    return <p className="text-center font-bold text-slate-500 py-10">{t('loading')}</p>;
  }

  if (!cards.length) {
    return (
      <div className="bg-white rounded-3xl border-2 border-dashed border-slate-300 p-8 text-center space-y-4">
        <span className="text-4xl block">📭</span>
        <p className="font-bold text-slate-600">{t('lblNoCards')}</p>
        <div className="flex justify-center gap-3 flex-wrap">
          <Link to={`/mazo/${deckId}`} className="bg-indigo-600 text-white font-extrabold px-6 py-3 rounded-2xl">
            ✏️ {t('btnEdit')}
          </Link>
          <Link to="/" className="bg-slate-100 text-slate-800 font-bold px-6 py-3 rounded-2xl">
            {t('btnGoBackHome')}
          </Link>
        </div>
      </div>
    );
  }

  if (finished) {
    return <CongratsPanel reviewed={reviewed} />;
  }

  const progressPercent = (index / cards.length) * 100;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <Link
          to="/"
          onClick={() => playSound('click')}
          className="text-slate-600 hover:text-slate-900 font-extrabold flex items-center gap-1.5 rounded-2xl p-2 bg-slate-100"
        >
          <span>⬅️</span> <span>{t('btnGoBackHome')}</span>
        </Link>
        <div className="text-center md:text-right">
          <span className="text-xs uppercase tracking-widest text-indigo-600 font-extrabold block">
            {t('lblStudyingMazo')}
          </span>
          <h1 className="font-black text-indigo-950">
            {deck?.emoji} {deckTitle(deck, language)}
          </h1>
        </div>
      </div>

      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2">
        <div className="flex justify-between items-center text-sm font-bold text-slate-600">
          <span>{t('lblProgressTitle')}</span>
          <span className="font-black text-indigo-600">
            {t('lblCard')} {index + 1} {t('lblOf')} {cards.length}
          </span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-4">
          <div
            className="bg-gradient-to-r from-blue-500 to-indigo-600 h-4 rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      <Flashcard
        front={sideText(current, language, 'front')}
        back={sideText(current, language, 'back')}
        flipped={flipped}
        onFlip={() => setFlipped((value) => !value)}
        onSpeak={(text) => speakText(text)}
      />

      <div className="bg-white border-2 border-slate-200 rounded-3xl p-6 shadow-md space-y-4">
        <h3 className="text-center font-black text-slate-700">{t('lblDidYouRemember')}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => handleEvaluate(false)}
            className="bg-red-50 hover:bg-red-100 text-red-900 border-4 border-red-500 p-4 rounded-2xl font-black shadow-sm flex flex-col items-center justify-center gap-1"
          >
            <span className="text-3xl">🔴</span>
            <span>{t('btnKeepReviewing')}</span>
            <span className="text-xs font-bold text-red-700 uppercase">{t('subKeepReviewing')}</span>
          </button>
          <button
            type="button"
            onClick={() => handleEvaluate(true)}
            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-950 border-4 border-emerald-500 p-4 rounded-2xl font-black shadow-sm flex flex-col items-center justify-center gap-1"
          >
            <span className="text-3xl">🟢</span>
            <span>{t('btnRemembered')}</span>
            <span className="text-xs font-bold text-emerald-700 uppercase">{t('subRemembered')}</span>
          </button>
        </div>
      </div>
    </div>
  );
}