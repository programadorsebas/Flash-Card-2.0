import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { getLeitnerSummary, listDecks } from '@/lib/memorable/decks';
import { playSound } from '@/lib/memorable/audio';
import DeckCard from '@/components/memorable/DeckCard';
import LeitnerBoxes from '@/components/memorable/LeitnerBoxes';

export default function Home() {
  const { user } = useAuth();
  const { t, stars, awards, streak } = useSettings();
  const [decks, setDecks] = useState(null);
  const [summary, setSummary] = useState(null);

  const load = useCallback(async () => {
    const [deckList, boxSummary] = await Promise.all([listDecks(), getLeitnerSummary(user?.id)]);
    setDecks(deckList);
    setSummary(boxSummary);
  }, [user?.id]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="space-y-8">
      <section className="bg-gradient-to-r from-indigo-700 via-blue-600 to-indigo-800 text-white p-6 rounded-3xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border-b-4 border-indigo-900">
        <div className="space-y-2 text-center md:text-left">
          <h1 className="font-black text-white">{t('welcomeTitle')}</h1>
          <p className="text-blue-100">{t('welcomeSubtitle')}</p>
          <div className="flex gap-2 flex-wrap justify-center md:justify-start pt-2">
            <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold border border-white/20">
              🏆 {awards} {t('awardLabel')}
            </span>
            <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold border border-white/20">
              ⭐ {stars} {t('starLabel')}
            </span>
          </div>
        </div>
        <div className="bg-amber-400 text-slate-900 px-6 py-4 rounded-2xl border-2 border-white text-center shrink-0 shadow-lg rotate-1">
          <span className="block text-xs font-extrabold uppercase tracking-widest text-amber-950">{t('streakTitle')}</span>
          <span className="text-3xl font-black block">
            🔥 {streak} <span className="text-base">{t('streakDays')}</span>
          </span>
        </div>
      </section>

      <section className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-3xl p-6 text-white shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <span className="bg-emerald-700/50 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
              ¡NUEVO! • NEW!
            </span>
            <h2 className="font-black text-white flex items-center gap-2">
              <span>🧘</span> <span>{t('gymTitle')}</span>
            </h2>
          </div>
          <span className="text-4xl animate-pulse">🌟</span>
        </div>
        <p className="text-emerald-50">{t('gymDesc')}</p>
        <Link
          to="/relax"
          onClick={() => playSound('click')}
          className="inline-flex items-center gap-2 bg-white text-emerald-900 hover:bg-emerald-50 font-black px-6 py-3.5 rounded-2xl shadow-md"
        >
          🧘 <span>{t('gymBtn')}</span>
        </Link>
      </section>

      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 className="font-black text-slate-800 flex items-center gap-2">
            <span>📚</span> <span>{t('sectionDecks')}</span>
          </h2>
          <div className="flex gap-2 flex-wrap">
            <Link
              to="/crear"
              onClick={() => playSound('click')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-5 py-2.5 rounded-2xl shadow-md flex items-center gap-2"
            >
              <span>➕</span> <span>{t('btnCreateDeck')}</span>
            </Link>
            <Link
              to="/crear-ia"
              onClick={() => playSound('click')}
              className="bg-amber-400 hover:bg-amber-500 text-slate-900 font-extrabold px-5 py-2.5 rounded-2xl shadow-md flex items-center gap-2"
            >
              <span>🤖</span> <span>{t('btnCreateAI')}</span>
            </Link>
          </div>
        </div>

        {decks === null ? (
          <p className="font-bold text-slate-500 py-6 text-center">{t('loading')}</p>
        ) : decks.length === 0 ? (
          <p className="font-bold text-slate-500 py-6 text-center bg-white rounded-2xl border border-dashed border-slate-300 p-6">
            {t('lblNoDecks')}
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {decks.map((deck) => (
              <DeckCard key={deck.id} deck={deck} cardCount={summary?.cardsByDeck?.[deck.id] || 0} />
            ))}
          </div>
        )}
      </section>

      <LeitnerBoxes summary={summary} />
    </div>
  );
}