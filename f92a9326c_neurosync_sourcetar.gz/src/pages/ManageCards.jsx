import React, { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { boxOf, deckTitle, listCards, myProgressByCard, removeCardProgress } from '@/lib/memorable/decks';
import { playSound } from '@/lib/memorable/audio';
import AddCardForm from '@/components/memorable/AddCardForm';
import CardRow from '@/components/memorable/CardRow';

export default function ManageCards() {
  const { deckId } = useParams();
  const { user } = useAuth();
  const { t, language } = useSettings();
  const [deck, setDeck] = useState(null);
  const [cards, setCards] = useState(null);
  const [progress, setProgress] = useState({});

  const load = useCallback(async () => {
    const [deckRecord, cardList] = await Promise.all([base44.entities.Deck.get(deckId), listCards(deckId)]);
    const progressMap = await myProgressByCard(deckId, user?.id);
    setDeck(deckRecord);
    setCards(cardList);
    setProgress(progressMap);
  }, [deckId, user?.id]);

  useEffect(() => {
    load();
  }, [load]);

  const handleDelete = async (card) => {
    await base44.entities.Card.delete(card.id);
    await removeCardProgress(card.id);
    await load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b border-slate-200 pb-4">
        <Link
          to="/"
          onClick={() => playSound('click')}
          className="text-slate-600 hover:text-slate-900 font-extrabold flex items-center gap-1.5 rounded-2xl p-2 bg-slate-100"
        >
          ⬅️ <span>{t('btnGoBackDecks')}</span>
        </Link>
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="font-black text-slate-800">
            {deck?.emoji} {deckTitle(deck, language)}
          </h1>
          <Link
            to={`/estudiar/${deckId}`}
            onClick={() => playSound('click')}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-4 py-2 rounded-2xl shadow-md"
          >
            ▶️ {t('btnStudy')}
          </Link>
        </div>
      </div>

      <AddCardForm deckId={deckId} onAdded={load} />

      <div className="space-y-4">
        <h3 className="font-bold text-slate-800">{t('lblCurrentCardsList')}</h3>

        {cards === null ? (
          <p className="font-bold text-slate-500 py-6 text-center">{t('loading')}</p>
        ) : cards.length === 0 ? (
          <div className="text-center p-8 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
            <span className="text-3xl block">📭</span>
            <p className="font-bold text-slate-500 mt-2">{t('lblNoCards')}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {cards.map((card) => (
              <CardRow
                key={card.id}
                card={card}
                box={boxOf(progress, card.id)}
                canDelete={card.created_by_id === user?.id}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}