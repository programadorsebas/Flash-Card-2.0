import React from 'react';
import { Link } from 'react-router-dom';
import { useSettings } from '@/lib/memorable/SettingsContext';
import { playSound } from '@/lib/memorable/audio';
import RelaxCircle from '@/components/memorable/RelaxCircle';

export default function Relax() {
  const { t } = useSettings();

  return (
    <div className="space-y-6 bg-white p-8 rounded-3xl border-2 border-indigo-100 shadow-xl text-center">
      <h1 className="font-black text-indigo-900">{t('relaxTitle')}</h1>
      <p className="text-slate-600 max-w-md mx-auto">{t('relaxDesc')}</p>

      <RelaxCircle />

      <div className="space-y-4">
        <p className="text-sm font-bold text-indigo-600">{t('relaxInstruction')}</p>
        <Link
          to="/"
          onClick={() => playSound('click')}
          className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black px-8 py-3 rounded-2xl shadow-md"
        >
          🏠 <span>{t('relaxBack')}</span>
        </Link>
      </div>
    </div>
  );
}