import React from 'react';
import { Link } from 'react-router-dom';
import { useSettings } from '@/lib/memorable/SettingsContext';
import AiPromptForm from '@/components/memorable/AiPromptForm';
import AiFileForm from '@/components/memorable/AiFileForm';

export default function CreateWithAI() {
  const { t } = useSettings();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
        <div>
          <h1 className="font-black text-slate-800 flex items-center gap-2">
            <span>🤖</span> <span>{t('aiPageTitle')}</span>
          </h1>
          <p className="text-slate-600">{t('aiPageDesc')}</p>
        </div>
        <Link to="/" className="text-slate-500 hover:text-slate-700 font-bold px-3 py-1.5 bg-slate-100 rounded-xl shrink-0">
          {t('btnCancel')}
        </Link>
      </div>

      <AiPromptForm />
      <AiFileForm />
    </div>
  );
}